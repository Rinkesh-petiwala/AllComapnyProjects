﻿using RinkeshPetiwala_Practical.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RinkeshPetiwala_Practical.Repositories.Departments
{
    public interface IDepartmentService
    {
        public Task<List<RinkeshPetiwala_Practical.Models.Department>> GetDepartmentListAsync();
    }
}
