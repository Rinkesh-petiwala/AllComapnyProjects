﻿using Microsoft.EntityFrameworkCore;
using RinkeshPetiwala_Practical.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RinkeshPetiwala_Practical.Repositories.Departments
{
    public class DepartmentService : IDepartmentService
    {
        private readonly DataContext _dbContext;
        public DepartmentService(DataContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<Department>> GetDepartmentListAsync()
        {
            var departments = await _dbContext.Department.ToListAsync();
            return departments;
        }

    }
}
