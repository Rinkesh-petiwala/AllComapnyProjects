﻿namespace RinkeshPetiwala_Practical.Repositories.Employee
{
    public class IEmployeeService
    {
    }
}
