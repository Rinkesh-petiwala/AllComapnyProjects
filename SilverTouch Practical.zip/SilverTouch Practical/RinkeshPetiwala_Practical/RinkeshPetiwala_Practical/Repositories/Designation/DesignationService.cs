﻿namespace RinkeshPetiwala_Practical.Repositories.Designation
{
    public class DesignationService
    {
    }
}
