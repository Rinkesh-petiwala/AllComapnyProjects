﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RinkeshPetiwala_Practical.Models;
using RinkeshPetiwala_Practical.Repositories.Departments;

namespace RinkeshPetiwala_Practical.Controllers
{
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly IDepartmentService _departmentService;
        public DepartmentController(IDepartmentService departmentService)
        {
            _departmentService = departmentService;
        }
        [HttpGet]
        [Route("list")]
        public async Task<IActionResult> Get()
        {
            try
            {
                var departments = await _departmentService.GetDepartmentListAsync();
                return Ok(departments);
            }
            catch (Exception ex)
            {

            }
            return Ok();
        }
    }
}
