﻿namespace RinkeshPetiwala_Practical.Models
{
    public class Designation
    {
        public int Id { get; set; }
        public string DepartmentName { get; set; }
    }
}
